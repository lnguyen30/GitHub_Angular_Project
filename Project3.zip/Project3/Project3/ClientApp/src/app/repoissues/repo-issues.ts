export class RepoIssues {

  title: string
  created_at: string;
  html_url: string;
}
