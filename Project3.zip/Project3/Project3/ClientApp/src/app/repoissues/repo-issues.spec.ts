import { RepoIssues } from './repo-issues';

describe('RepoIssues', () => {
  it('should create an instance', () => {
    expect(new RepoIssues()).toBeTruthy();
  });
});
