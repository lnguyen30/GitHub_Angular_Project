import { TestBed } from '@angular/core/testing';

import { RepoIssuesService } from './repo-issues.service';

describe('RepoIssuesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RepoIssuesService = TestBed.get(RepoIssuesService);
    expect(service).toBeTruthy();
  });
});
