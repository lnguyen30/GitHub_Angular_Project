import { User } from "../user/user";


export class Repo {

  //owner avatar?
  items: string[];
  name:string;
  html_url: string;
  description: string;
  stargazers_count: number;
  watchers_count: number;
  forks: number;
  open_issues_count: number;
  language: string;
  owner: User[];
  avatar_url: string;
  clone_url: string;

  page: number;
  per_page: number;
  total_count: number;

}
