import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from "rxjs/operators";
import { Commit } from './commit';

//Service to search for repo by calling api with query string

@Injectable({
  providedIn: 'root'
})
export class CommitService {

  baseApiUrl: string = "https://api.github.com/search/repositories?";
  detailRepoUrl: string = "https://api.github.com/repos/"

  constructor(private httpClient:HttpClient) { }

  fetchRepoCommits(query:string, repo: string): Observable<Commit>{

   return this.httpClient.get<Commit>(`${this.detailRepoUrl}${query}/${repo}/commits`)
   .pipe(catchError(this.handleError));
  }




  private handleError(error: HttpErrorResponse) {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error("An error occurred:", error.error.message);
    } else {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      console.error(
        `Backend returned code ${error.status}, ` + `body was: ${error.error}`
      );
      if (error.status === 404) {
        return throwError("That resource could not be found.");
      }
    }
    // return an observable with a user-facing error message
    return throwError("Something bad happened; please try again later.");
  }


}
