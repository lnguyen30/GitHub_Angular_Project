import { Commit } from './commit';

describe('Commit', () => {
  it('should create an instance', () => {
    expect(new Commit()).toBeTruthy();
  });
});
