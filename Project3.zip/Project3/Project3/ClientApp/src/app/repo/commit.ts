import { User } from "../user/user";

export class Commit {
  author: User;
  html_url: string;
  message: string;
  comment_count: string;
}
