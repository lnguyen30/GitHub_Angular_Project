import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Repo } from '../repo/repo';
import { User } from '../user/user';
import { UserService } from '../user/user.service';
import { UserDetail } from './user-detail';

@Component({
  selector: 'app-user-detail',
  templateUrl: './user-detail.component.html',
  styleUrls: ['./user-detail.component.css']
})
export class UserDetailComponent implements OnInit {

  user: UserDetail; // holds user's info
  user_RepoList: Repo; //holds user's repos
  user_FollowerList: User; //holds user's follower's lists
  error: string;

  constructor(private route: ActivatedRoute, private userService: UserService) { }

  ngOnInit() {

    let userName = this.route.snapshot.paramMap.get('login');

    //fetches user's additional details by calling searchUserDetails api
    this.userService.searchUserDetails(userName).subscribe(
      (data: UserDetail) => {
        this.user=data;
        console.log(this.user);
      },
      (error: any)=>{
        this.error= error;
      }
    )

    this.userService.fetchUserRepos(userName).subscribe(
      (data: Repo) =>{
        if(data.language===null){
          data.language ="N/A"
          this.user_RepoList.language=data.language;
        }
        this.user_RepoList = data;
      },
      (error: any)=>{
        this.error= error;
      }
    )


    this.userService.fetchFollowers(userName).subscribe(
      (data: User)=> {
        this.user_FollowerList=data;
      },
      (error: any)=>{
        this.error= error;
      }

    )

  }

}
