export class UserDetail {

  avatar_url: string;
  login: string;
  id: number;
  name: string;
  blog: string;
  location: string;
  html_url: string;

}
