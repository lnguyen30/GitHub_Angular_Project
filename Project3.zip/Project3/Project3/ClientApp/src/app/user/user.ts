export class User {
  items: string[];
  login: string;
  id: number;
  avatar_url: string;
  name: string;
  blog: string;
  location: string;
  html_url: string;
  repos_url: string;
  followers_url: string;



  page: number;
  per_page: number;
  total_count: number;
}
