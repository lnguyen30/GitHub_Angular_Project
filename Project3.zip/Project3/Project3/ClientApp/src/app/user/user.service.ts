import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Repo } from '../repo/repo';
import { UserDetail } from '../user-detail/user-detail';
import { User } from './user';

//Search for user with API url + query string parameter

@Injectable({
  providedIn: 'root'
})
export class UserService {

  baseApiUrl: string = "https://api.github.com/search/users?";
  detailUserUrl: string ="https://api.github.com/users/";

  constructor(private httpClient:HttpClient) { }

  searchUser(query:string, page: number): Observable<User>{
   return this.httpClient.get<User>(`${this.baseApiUrl}q=${query}+in:user&per_page=10&page=${page}`)
  }

  searchUserDetails(query:string): Observable<UserDetail>{
    return this.httpClient.get<UserDetail>(`${this.detailUserUrl}${query}`)
   }

   fetchUserRepos(query:string): Observable<Repo>{
     return this.httpClient.get<Repo>(`${this.detailUserUrl}${query}/repos`)
   }

   fetchFollowers(query: string): Observable<User>{
    return this.httpClient.get<User>(`${this.detailUserUrl}${query}/followers`)
   }

}
