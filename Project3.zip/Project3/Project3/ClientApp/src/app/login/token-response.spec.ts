import { TokenResponse } from './token-response';

describe('TokenResponse', () => {
  it('should create an instance', () => {
    expect(new TokenResponse()).toBeTruthy();
  });
});
