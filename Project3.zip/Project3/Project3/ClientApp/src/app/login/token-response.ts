export class TokenResponse {
  access_token: string;

}
