import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Commit } from '../repo/commit';
import { CommitService } from '../repo/commit.service';
import { Repo } from '../repo/repo';
import { RepoService } from '../repo/repo.service';
import { RepoIssues } from '../repoissues/repo-issues';
import { RepoIssuesService } from '../repoissues/repo-issues.service';
import { RepoDetails } from './repo-details';

@Component({
  selector: 'app-repo-details',
  templateUrl: './repo-details.component.html',
  styleUrls: ['./repo-details.component.css']
})
export class RepoDetailsComponent implements OnInit {

  repo: RepoDetails;
  commit: Commit;
  issues: RepoIssues;


  constructor(private route: ActivatedRoute, private repoService: RepoService,
    private commitService: CommitService, private issuesservice: RepoIssuesService ) { }

  ngOnInit() {

    let repo = this.route.snapshot.paramMap.get('name');
    let owner = this.route.snapshot.paramMap.get('login');



    this.repoService.searchRepoDetails(owner, repo).subscribe(
      (data: RepoDetails) => {
        this.repo=data;
        console.log(this.repo);
      }
    )

    this.commitService.fetchRepoCommits(owner, repo).subscribe(
    (data: Commit)=> {
      this.commit=data;
    }
  )

    this.issuesservice.fetchRepoIssues(owner, repo).subscribe(
      (data: RepoIssues)=> {
        this.issues = data;
      }
    )

  }

}
