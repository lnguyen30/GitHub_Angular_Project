import { RepoDetails } from './repo-details';

describe('RepoDetails', () => {
  it('should create an instance', () => {
    expect(new RepoDetails()).toBeTruthy();
  });
});
