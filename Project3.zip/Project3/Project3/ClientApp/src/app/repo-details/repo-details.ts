import { Url } from "url";
import { UserDetail } from "../user-detail/user-detail";

export class RepoDetails {

  name:string;
  html_url: string;
  description: string;
  stargazers_count: number;
  watchers_count: number;
  forks: number;
  open_issues_count: number;
  language: string;
  owner: UserDetail;
  clone_url: string;
}

