import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { Repo } from '../repo/repo';
import { RepoService } from '../repo/repo.service';
import { User } from '../user/user';
import { UserService } from '../user/user.service';

@Component({
  selector: 'app-default-search',
  templateUrl: './default-search.component.html',
  styleUrls: ['./default-search.component.css']
})
export class DefaultSearchComponent implements OnInit {

  // objects that will hold user data or repo data

  resultUsers: User;
  resultRepos: Repo;

  // string from text search box
  userSearch: string;
  repoSearch: string;

  //error message
  error: string;

  //Page variables
  searchToggle: boolean; // true = User, else Repo
  pageNumber: number;
  pageResultSize: number;
  amount_result: number;

  //search type to choose from drop down list
  options: string[] = ["User", "Repository"];


searchForm: FormGroup;

 // query: username/reponame    choice: User type/ Repo Type
  constructor(private userService: UserService, private repoService: RepoService) { this.searchForm = new FormGroup({
    query: new FormControl(""),
    choice: new FormControl("")

  });

}

  ngOnInit() {
    this.searchToggle = true;
    this.pageNumber= 1;
    this.pageResultSize = 10;
    this.amount_result = 0;
  }

resetState(){
  this.resultRepos=null;
  this.resultUsers=null;
  this.error=null;

}




toggleSwitch(){

    this.pageNumber = 1;
    this.resetState();
    this.amount_result=0;

}


searchByPage(page: number){
  this.pageNumber = page;
  if(this.searchForm.get("choice").value==="User"){
    this.resetState();
    this.searchForUsers();
  }

  if(this.searchForm.get("choice").value==="Repository"){
    console.log('Searching repo from if statement ngSubmit');
    this.resetState();
    this.searchForRepos();
  }

}


submitForm(){

  if(this.searchForm.get("choice").value==="")
    this.error="option not selected"
  // if user type is selected -> call search user func
  if(this.searchForm.get("choice").value==="User"){
    this.searchForUsers();
  }
  // if repo type is selected -> call search repo func
  if(this.searchForm.get("choice").value==="Repository"){
    console.log('Searching repo from if statement ngSubmit');
    this.searchForRepos();
  }
}

searchForUsers(){
  console.log("Searching for user");

this.userSearch = this.searchForm.get('query').value;
this.userService.searchUser(this.userSearch, this.pageNumber)
.subscribe(
  (data: User)=>{

    if(data.total_count===0)
          this.error= "User not found";

    this.resultUsers = data;
    console.log(this.resultUsers);
    this.amount_result = this.resultUsers.total_count;

  }
)

}

  searchForRepos(){
    this.resetState();
    console.log("search for repos");
    this.repoSearch = this.searchForm.get('query').value;

    this.repoService.searchRepo(this.repoSearch, this.pageNumber)
    .subscribe(
      (data: Repo)=>{
        if(data.total_count===0)
          this.error= "Repository not found";


        this.resultRepos = data;
        this.amount_result = this.resultRepos.total_count;
        console.log(this.resultRepos);
      },
      (error: any) => {
        this.error = error;
      }
    );
  }

}
