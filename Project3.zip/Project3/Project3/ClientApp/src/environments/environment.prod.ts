export const environment = {
  production: true,
  clientId: "0133229554f60bd2ad16"
};
