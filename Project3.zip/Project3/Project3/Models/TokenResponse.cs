﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Project3.Models
{
    public class TokenResponse
    {

        public string access_token { get; set; }
    }
}
